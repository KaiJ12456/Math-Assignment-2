#include "PhysicsPlayground.h"
#include "Utilities.h"

PhysicsPlayground::PhysicsPlayground(std::string name)
	: Scene(name)
{
	//Gravity
	m_gravity = b2Vec2(0.f, -100.f);
	m_physicsWorld->SetGravity(m_gravity);

}

bool end = false, cont = false;
void WinScreen(float posX, float posY) {

	//Creates entity
	auto entity = ECS::CreateEntity();

	//Add components
	ECS::AttachComponent<Sprite>(entity);
	ECS::AttachComponent<Transform>(entity);

	//setup the components
	std::string fileName = "WinPicture.png";
	ECS::GetComponent<Sprite>(entity).LoadSprite(fileName, 270, 200);
	ECS::GetComponent<Transform>(entity).SetPosition(vec3(0.f, 0.f, 3.f));
}


void PhysicsPlayground::InitScene(float windowWidth, float windowHeight)
{
	//Dyanmically allocates the register
	m_sceneReg = new entt::registry;

	//Attach the register
	ECS::AttachRegister(m_sceneReg);

	//Sets up aspect ratio for camera
	float aspectRatio = windowWidth / windowHeight;

	//Setup MainCamera Entity
	{
		//Creates Camera entity
		auto entity = ECS::CreateEntity();
		ECS::SetIsMainCamera(entity, true);

		//Creates new orthographic camera
		ECS::AttachComponent<Camera>(entity);
		ECS::AttachComponent<HorizontalScroll>(entity);
		ECS::AttachComponent<VerticalScroll>(entity);

		vec4 temp = vec4(-75.f, 75.f, -75.f, 75.f);
		ECS::GetComponent<Camera>(entity).SetOrthoSize(temp);
		ECS::GetComponent<Camera>(entity).SetWindowSize(vec2(float(windowWidth), float(windowHeight)));
		ECS::GetComponent<Camera>(entity).Orthographic(aspectRatio, temp.x, temp.y, temp.z, temp.w, -100.f, 100.f);


		//Attaches the camera to vert and horizontal scrolls
		ECS::GetComponent<HorizontalScroll>(entity).SetCam(&ECS::GetComponent<Camera>(entity));
		ECS::GetComponent<VerticalScroll>(entity).SetCam(&ECS::GetComponent<Camera>(entity));
	}

	//Setup new entity
	{
		//Creates entity
		auto entity = ECS::CreateEntity();

		//Add components
		ECS::AttachComponent<Sprite>(entity);
		ECS::AttachComponent<Transform>(entity);

		//setup the components
		std::string fileName = "BackGround.png";
		ECS::GetComponent<Sprite>(entity).LoadSprite(fileName, 500, 300);
		ECS::GetComponent<Sprite>(entity).SetTransparency(0.5f);
		ECS::GetComponent<Transform>(entity).SetPosition(vec3(0.f,100.f, 0.f));
	}

	//Setup Character
	{
		auto entity = ECS::CreateEntity();
		ECS::SetIsMainPlayer(entity, true);

		//Add components
		ECS::AttachComponent<Sprite>(entity);
		ECS::AttachComponent<Transform>(entity);
		ECS::AttachComponent<PhysicsBody>(entity);

		//Sets up the components
		std::string fileName = "Ball.png";
		ECS::GetComponent<Sprite>(entity).LoadSprite(fileName, 25, 25);
		ECS::GetComponent<Sprite>(entity).SetTransparency(1.f);
		ECS::GetComponent<Transform>(entity).SetPosition(vec3(0.f, 30.f, 2.f));

		auto& tempSpr = ECS::GetComponent<Sprite>(entity);
		auto& tempPhsBody = ECS::GetComponent<PhysicsBody>(entity);

		float shrinkX = 10.f;
		float shrinkY = 10.f;

		b2Body* tempBody;
		b2BodyDef tempDef;
		tempDef.type = b2_dynamicBody;
		tempDef.position.Set(float32(0.f), float32(30.f));

		tempBody = m_physicsWorld->CreateBody(&tempDef);

		tempPhsBody = PhysicsBody(tempBody, float(tempSpr.GetWidth() - shrinkX) , float(tempSpr.GetHeight() - shrinkY), vec2(0.f, 0.f), false);

		ECS::GetComponent<PhysicsBody>(MainEntities::MainPlayer()).GetBody()->SetFixedRotation(true);
	}

	//Setup IceCube1
	{
		//Creates entity
		auto entity = ECS::CreateEntity();

		//Add components
		ECS::AttachComponent<Sprite>(entity);
		ECS::AttachComponent<Transform>(entity);
		ECS::AttachComponent<PhysicsBody>(entity);

		//Sets up components
		std::string fileName = "ice.png";
		ECS::GetComponent<Sprite>(entity).LoadSprite(fileName, 20, 20);
		ECS::GetComponent<Transform>(entity).SetPosition(vec3(-30.f, -20.f, 2.f));

		auto& tempSpr = ECS::GetComponent<Sprite>(entity);
		auto& tempPhsBody = ECS::GetComponent<PhysicsBody>(entity);

		float shrinkX = 0.f;
		float shrinkY = 0.f;

		b2Body* tempBody;
		b2BodyDef tempDef;
		tempDef.type = b2_dynamicBody;
		tempDef.position.Set(float32(-30.f), float32(-20.f));

		tempBody = m_physicsWorld->CreateBody(&tempDef);

		tempPhsBody = PhysicsBody(tempBody, float(tempSpr.GetWidth() - shrinkX), float(tempSpr.GetHeight() - shrinkY), vec2(0.f, 0.f), false);
	}

	//Set up BASELINE
	{
		//Creates entity
		auto entity = ECS::CreateEntity();

		//Add components
		ECS::AttachComponent<Sprite>(entity);
		ECS::AttachComponent<Transform>(entity);
		ECS::AttachComponent<PhysicsBody>(entity);

		//Sets up components
		std::string fileName = "ground2.png";
		ECS::GetComponent<Sprite>(entity).LoadSprite(fileName, 2000, 30);
		ECS::GetComponent<Transform>(entity).SetPosition(vec3(30.f, -20.f, 2.f));

		auto& tempSpr = ECS::GetComponent<Sprite>(entity);
		auto& tempPhsBody = ECS::GetComponent<PhysicsBody>(entity);

		float shrinkX = 0.f;
		float shrinkY = 0.f;
		b2Body* tempBody;
		b2BodyDef tempDef;
		tempDef.type = b2_staticBody;
		tempDef.position.Set(float32(30.f), float32(-20.f));

		tempBody = m_physicsWorld->CreateBody(&tempDef);

		tempPhsBody = PhysicsBody(tempBody, float(tempSpr.GetWidth() - shrinkX), float(tempSpr.GetHeight() - shrinkY), vec2(0.f, 0.f), false);
	}
	//Set up PLAT1
	{
		//Creates entity
		auto entity = ECS::CreateEntity();

		//Add components
		ECS::AttachComponent<Sprite>(entity);
		ECS::AttachComponent<Transform>(entity);
		ECS::AttachComponent<PhysicsBody>(entity);

		//Sets up components
		std::string fileName = "ground2.png";
		ECS::GetComponent<Sprite>(entity).LoadSprite(fileName, 50, 30);
		ECS::GetComponent<Transform>(entity).SetPosition(vec3(30.f, -20.f, 2.f));

		auto& tempSpr = ECS::GetComponent<Sprite>(entity);
		auto& tempPhsBody = ECS::GetComponent<PhysicsBody>(entity);

		float shrinkX = 0.f;
		float shrinkY = 0.f;
		b2Body* tempBody;
		b2BodyDef tempDef;
		tempDef.type = b2_staticBody;
		tempDef.position.Set(float32(50.f), float32(60.f));

		tempBody = m_physicsWorld->CreateBody(&tempDef);

		tempPhsBody = PhysicsBody(tempBody, float(tempSpr.GetWidth() - shrinkX), float(tempSpr.GetHeight() - shrinkY), vec2(0.f, 0.f), false);
	}

	//Set up Plat2
	{
		//Creates entity
		auto entity = ECS::CreateEntity();

		//Add components
		ECS::AttachComponent<Sprite>(entity);
		ECS::AttachComponent<Transform>(entity);
		ECS::AttachComponent<PhysicsBody>(entity);

		//Sets up components
		std::string fileName = "ground2.png";
		ECS::GetComponent<Sprite>(entity).LoadSprite(fileName, 50, 30);
		ECS::GetComponent<Transform>(entity).SetPosition(vec3(30.f, -20.f, 2.f));

		auto& tempSpr = ECS::GetComponent<Sprite>(entity);
		auto& tempPhsBody = ECS::GetComponent<PhysicsBody>(entity);

		float shrinkX = 0.f;
		float shrinkY = 0.f;
		b2Body* tempBody;
		b2BodyDef tempDef;
		tempDef.type = b2_staticBody;
		tempDef.position.Set(float32(100.f), float32(120.f));

		tempBody = m_physicsWorld->CreateBody(&tempDef);

		tempPhsBody = PhysicsBody(tempBody, float(tempSpr.GetWidth() - shrinkX), float(tempSpr.GetHeight() - shrinkY), vec2(0.f, 0.f), false);
	}

	//Set up Plat3
	{
		//Creates entity
		auto entity = ECS::CreateEntity();

		//Add components
		ECS::AttachComponent<Sprite>(entity);
		ECS::AttachComponent<Transform>(entity);
		ECS::AttachComponent<PhysicsBody>(entity);

		//Sets up components
		std::string fileName = "ground2.png";
		ECS::GetComponent<Sprite>(entity).LoadSprite(fileName, 200, 30);
		ECS::GetComponent<Transform>(entity).SetPosition(vec3(30.f, -20.f, 2.f));

		auto& tempSpr = ECS::GetComponent<Sprite>(entity);
		auto& tempPhsBody = ECS::GetComponent<PhysicsBody>(entity);

		float shrinkX = 0.f;
		float shrinkY = 0.f;
		b2Body* tempBody;
		b2BodyDef tempDef;
		tempDef.type = b2_staticBody;
		tempDef.position.Set(float32(-80.f), float32(155.f));

		tempBody = m_physicsWorld->CreateBody(&tempDef);

		tempPhsBody = PhysicsBody(tempBody, float(tempSpr.GetWidth() - shrinkX), float(tempSpr.GetHeight() - shrinkY), vec2(0.f, 0.f), false);
	}
	//Setup IceCube2
	{
		//Creates entity
		auto entity = ECS::CreateEntity();

		//Add components
		ECS::AttachComponent<Sprite>(entity);
		ECS::AttachComponent<Transform>(entity);
		ECS::AttachComponent<PhysicsBody>(entity);

		//Sets up components
		std::string fileName = "ice.png";
		ECS::GetComponent<Sprite>(entity).LoadSprite(fileName, 20, 20);
		ECS::GetComponent<Transform>(entity).SetPosition(vec3(-30.f, -20.f, 2.f));

		auto& tempSpr = ECS::GetComponent<Sprite>(entity);
		auto& tempPhsBody = ECS::GetComponent<PhysicsBody>(entity);

		float shrinkX = 0.f;
		float shrinkY = 0.f;

		b2Body* tempBody;
		b2BodyDef tempDef;
		tempDef.type = b2_dynamicBody;
		tempDef.position.Set(float32(-10.f), float32(180.f));

		tempBody = m_physicsWorld->CreateBody(&tempDef);

		tempPhsBody = PhysicsBody(tempBody, float(tempSpr.GetWidth() - shrinkX), float(tempSpr.GetHeight() - shrinkY), vec2(0.f, 0.f), false);

		
	}
	//Set up Plat4
	{
		//Creates entity
		auto entity = ECS::CreateEntity();

		//Add components
		ECS::AttachComponent<Sprite>(entity);
		ECS::AttachComponent<Transform>(entity);
		ECS::AttachComponent<PhysicsBody>(entity);

		//Sets up components
		std::string fileName = "ground2.png";
		ECS::GetComponent<Sprite>(entity).LoadSprite(fileName, 50, 30);
		ECS::GetComponent<Transform>(entity).SetPosition(vec3(30.f, -20.f, 2.f));

		auto& tempSpr = ECS::GetComponent<Sprite>(entity);
		auto& tempPhsBody = ECS::GetComponent<PhysicsBody>(entity);

		float shrinkX = 0.f;
		float shrinkY = 0.f;
		b2Body* tempBody;
		b2BodyDef tempDef;
		tempDef.type = b2_staticBody;
		tempDef.position.Set(float32(90.f), float32(230.f));

		tempBody = m_physicsWorld->CreateBody(&tempDef);

		tempPhsBody = PhysicsBody(tempBody, float(tempSpr.GetWidth() - shrinkX), float(tempSpr.GetHeight() - shrinkY), vec2(0.f, 0.f), false);
	}

	ECS::GetComponent<HorizontalScroll>(MainEntities::MainCamera()).SetFocus(&ECS::GetComponent<Transform>(MainEntities::MainPlayer()));
	ECS::GetComponent<VerticalScroll>(MainEntities::MainCamera()).SetFocus(&ECS::GetComponent<Transform>(MainEntities::MainPlayer()));
}	




int coolDown = 0;
bool canJump = true;
void PhysicsPlayground::Update()
{
	//Make a set of conditions that allow the player to win the game
	auto& pos = ECS::GetComponent<Transform>(MainEntities::MainPlayer());

	if ((pos.GetPositionY() >= 250 && pos.GetPositionX() >= 80)) {
		//std::cout << "You Win!\n";
		end = true;
		WinScreen(pos.GetPositionX(), pos.GetPositionY());
	}
	
	//Scene::AdjustScrollOffset();
	if(canJump == false)
		coolDown++;
	if (coolDown == 250) {
		canJump = true;
		coolDown = 0;
	}
}

float speed = 0.f;
int dir = 0, last = 0;
bool press = false;
float lastX = 0.f;
void PhysicsPlayground::KeyboardHold()
{
	auto& player = ECS::GetComponent<PhysicsBody>(MainEntities::MainPlayer());
	float accel = 0.1f;
	b2Vec2 vel = b2Vec2(0.f, 0.f);

	

	if (end == false)
	{
		if (Input::GetKey(Key::Shift))
		{
			speed = 30.f;
		}
		if (cont == false) {
			if (Input::GetKey(Key::A))
			{
				vel += b2Vec2(-1.f, 0.f);
				lastX = -1;
				dir = -1;
				if (last == dir) {
					if (speed < 6) accel = 0.3f;
					if (6 < speed && speed < 10)
						accel = 0.1f;
					else if (speed > 10)
						accel = 0.3f;
					if (speed <= 20) {
						speed += accel;
					}

					if (Input::GetKeyUp(Key::Shift)) {
						if (speed > 20)
							speed = 20;
					}
				}
				else
					speed = 0;
			}

			if (Input::GetKey(Key::D))
			{
				vel += b2Vec2(1.f, 0.f);
				lastX = 1;
				dir = 1;
				if (last == dir) {
					if (speed < 6) accel = 0.3f;
					if (6 < speed && speed < 10)
						accel = 0.1f;
					else if (speed > 10)
						accel = 0.3f;
					if (speed <= 20) {
						speed += accel;
					}

					if (Input::GetKeyUp(Key::Shift)) {
						if (speed > 20)
							speed = 20;
					}

				}
				else
					speed = 0;
			}

			if (!press) {
				accel = 1.f;
				speed -= accel;
			}

			if (speed > 0) {
				vel = b2Vec2(lastX, 0);
			}

			if (speed < 0)
				speed = 0;

			last = dir;
		}

		else
		{

			if (Input::GetKey(Key::A))

			{
				lastX = -1;
				dir = -1;
				vel += b2Vec2(-1.f, 0.f);

				if (last == dir) {
					accel = 0.3f;
					if (speed < 20) {
						speed += accel;
					}

				}
				else {
					speed = 0;
				}
			
			}

			if (Input::GetKey(Key::D))
			{
				lastX = 1;
				dir = 1;
				vel += b2Vec2(1.f, 0.f);

				if (last == dir) {
					accel = 0.3f;
					if (speed < 20) {
						speed += accel;
					}

				}
				else {
					speed = 0;
				}

			} 

			if (!press) {
				accel = 0.3;
				speed -= accel;
			}

			if (speed > 0) {
				vel = b2Vec2(lastX, 0);
			}

			if (speed < 0) {
				speed = 0;
			}
			last = dir;
		}

		if (canJump == true) {
			if (Input::GetKeyDown(Key::Space))
			{
				vel += b2Vec2(lastX, 500.f);
				canJump = false;
				std::cout << "Jumping\n";
			}
		}

		b2Vec2 newlinearVelocity = b2Vec2(
			speed * vel.x,
			player.GetBody()->GetLinearVelocity().y + vel.y);

		player.GetBody()->SetLinearVelocity(newlinearVelocity);
		std::cout << speed << "\t";
	}

}

void PhysicsPlayground::KeyboardDown()
{
	if (Input::GetKeyDown(Key::Enter)) {
		cont = !cont;
		std::cout << "Switched Controls\n";
	}
	if (Input::GetKeyDown(Key::A))
		press = true;
	if (Input::GetKeyDown(Key::D))
		press = true;
}

void PhysicsPlayground::KeyboardUp()
{
	if (Input::GetKeyUp(Key::A))
		press = false;
	if (Input::GetKeyUp(Key::D))
		press = false;
}
